@extends('layouts.app')


@section('style')

@endsection
@section('content')

        <div class="newsitem_text">



            <p><center><strong>NOTICE </strong></center></p>
            <hr>
            <p>All Ghanaian applicants for the 2018/2019 Academic year admission are required to use MoneyLendGh portal. The procedure for the online application process is as follows:</p>


            <center><p><strong>For more information call Gad 0505284060</strong></p></center>
            &nbsp;



    </div>
@endsection
@section('js')
@endsection